<?php $__env->startSection('content'); ?>
<div class="bg-blue-500 w-full px-0 py-5">
    <img src="<?php echo e(asset('images/logo.png')); ?>" alt="" class="h-[35px] w-auto mx-auto px-4">
</div>
<div class="bg-blue-500">
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('zametka');

$__html = app('livewire')->mount($__name, $__params, 'lw-2032864328-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    
</div>

<div class="absolute w-full text-center bottom-0 py-5 bg-blue-500 text-xl text-white font-semibold">
    Powered by <a href="https://instagram.com/mahmudov.shod" class="text-yellow-500">mahmudov.shod</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Vatan Agency\Desktop\zametka\resources\views/welcome.blade.php ENDPATH**/ ?>